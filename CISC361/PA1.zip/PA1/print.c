// Programming Assignment 1
// Sohan Gadiraju
#include "mp3.h"

extern mp3_t *head;

void print()
{
  mp3_t *temp;
  int  i = 0;

  temp = head;

  while (temp != NULL) {
    printf("(%d)--%s--%s---%d\n", ++i, temp->name, temp->title,temp->duration);
    temp = temp->next;
  }
}
